# 1. Assemble the package structure
dpkg-deb --build sentinel-pkg sentinel-v2-core.deb

# 2. Apply your "CVBGOD" signature
dpkg-sig -k 2ED0213EFEFE9340 --sign builder sentinel-v2-core.deb

# 3. Verify the signature
dpkg-sig --verify sentinel-v2-core.deb
